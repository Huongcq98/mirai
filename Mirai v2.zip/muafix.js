module.exports.config = {
  name: "mua",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Huong",
  description: "Mua sét té nước, set hắc long.",
  commandCategory: "Economy",
  usages: "",
  cooldowns: 10,
  dependencies: [],

};

module.exports.run = async ({ api, event, args, Currencies }) => {

  var data = await Currencies.getData(event.senderID);
  var money = data.money
  var i = 4000000
  var x = 6000000;
  if (args.length == 0) api.sendMessage("/mua [sette/sethaclong]", event.threadID, event.messageID)
  if (args[0] == "sette") {
    if (money < 6000000) api.sendMessage("Bạn không đủ tiền !", event.threadID, event.messageID)
    else {
      if (money > 6000000)
        return api.sendMessage("", event.threadID, () => api.sendMessage("Bạn đã mua set té nước, tài khoản của bạn bị trừ 6.000.000 coin.", event.threadID, () => Currencies.setData(event.senderID, options = { money: money - parseInt(x) }), event.messageID));
    }
  }
  else {
    if (args[0] == "sethaclong") {
      if (money < 4000000) api.sendMessage("Bạn không đủ tiền !", event.threadID, event.messageID)
      else {
        if (money > 4000000)
          return api.sendMessage("", event.threadID, () => api.sendMessage("Bạn đã mua set hắc long, tài khoản của bạn bị trừ 4.000.000 coin.", event.threadID, () => Currencies.setData(event.senderID, options = { money: money - parseInt(i) }), event.messageID));
      }
    }
  }
}