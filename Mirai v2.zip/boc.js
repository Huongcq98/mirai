module.exports.config = {
	name: "boc",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "Huong",
    description: "Thông tin game 7vnr.",
	commandCategory: "Economy",
	usages: "",
	cooldowns: 1,
	dependencies: [],
  
};

module.exports.run = async({api,event,args,Currencies}) => {
	const time = process.uptime(),
      hours = Math.floor(time / (60 * 60)),
      minutes = Math.floor((time % (60 * 60)) / 60),
      seconds = Math.floor(time % 60);
    
    
    const timeStart = Date.now();
    var data = await Currencies.getData(event.senderID);
    var money = data.money
    var i = 40000;
    if(args.length == 0) api.sendMessage("/boc [batho/bat100]", event.threadID, event.messageID)
    
    if (args[0] == "batho") { 
    return api.sendMessage("", event.threadID, () => api.sendMessage("Bạn đã bốc bát họ 40.000 đô và cầm về 32.000 đô.", event.threadID, () => Currencies.setData(event.senderID, options = {money: money + parseInt(i) - 8000}),event.messageID));
		}
	
 if (args[0] == "bat100") { 
    return api.sendMessage("", event.threadID, () => api.sendMessage("Bạn đã bốc bát họ 100.000 đô và cầm về 80.000 đô.", event.threadID, () => Currencies.setData(event.senderID, options = {money: money + parseInt(i) + 40000}),event.messageID));
		}

	}




