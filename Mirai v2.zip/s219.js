module.exports.config = {
	name: "s219",
	version: "1.0.0",
	hasPermssion: 0,
	credits: "Huong",
    description: "Thông tin game sv 219.",
	commandCategory: "Economy",
	usages: "",
	cooldowns: 10,
	dependencies: [],
  
};

module.exports.run = async({api,event,args,Currencies}) => {
	const time = process.uptime(),
      hours = Math.floor(time / (60 * 60)),
      minutes = Math.floor((time % (60 * 60)) / 60),
      seconds = Math.floor(time % 60);
    
    
    const timeStart = Date.now();
    if(args.length == 0) api.sendMessage("/s219 [all/ngay1/ngay2/ngay3/ngay4/ngay5/ngay6/ngay7/ngay8]", event.threadID, event.messageID)
    
    if (args[0] == "ngay1") { 
    return api.sendMessage("", event.threadID, () => api.sendMessage(
                      'Quà Máy chủ 219: Mở vào 10 giờ ngày 20/7/2021.\n' +
                      `Ngày 1: (20/7/2021): Kẹo AH Kaio + Viên Trang Bị (Đơn) Công Beerus + Bảo Rương Ước Nguyện*2..\n` +
                      `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
		}
    if (args[0] == "ngay2") {
      return api.sendMessage("", event.threadID, () => api.sendMessage(
        'Quà Máy chủ 219: Mở vào 10 giờ ngày 20/7/2021.\n' +
        `Ngày 2: (21/7/2021): Nhận ngay kẹo AH Kaio + Viên Trang Bị (Đơn) Công Broly + Bảo Rương Ước Nguyện*2.\n` +
        `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
    }
    if (args[0] == "ngay3") {
      return api.sendMessage("", event.threadID, () => api.sendMessage(
        'Quà Máy chủ 219: Mở vào 10 giờ ngày 20/7/2021.\n' +
        `Ngày 3: (22/7/2021): nhận Kẹo AH Kaio + Viên Trang Bị (Đơn) Tướng Quân + Bảo Rương Ước Nguyện*2\n` +
        `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
    }
    if (args[0] == "ngay4") {
      return api.sendMessage("", event.threadID, () => api.sendMessage(
        'Quà Máy chủ 219: Mở vào 10 giờ ngày 20/7/2021.\n' +
        `Ngày 4:  (23/7/2021): nhận Kẹo AH Kaio + Viên Trang Bị (Đơn) Thể Thao Trắng + Bảo Rương Ước Nguyện*2.\n` +
        `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
    }
    if (args[0] == "ngay5") {
      return api.sendMessage("", event.threadID, () => api.sendMessage(
        'Quà Máy chủ 219: Mở vào 10 giờ ngày 20/7/2021.\n' +
        `Ngày 5: (24/7/2021): nhận Kẹo AH Kaio + Viên Trang Bị (Đơn) Thần Long + Bảo Rương Ước Nguyện*2.\n` +
        `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
    }
    if (args[0] == "ngay6") {
      return api.sendMessage("", event.threadID, () => api.sendMessage(
        'Quà Máy chủ 219: Mở vào 10 giờ ngày 20/7/2021.\n' +
        `Ngày 6: (25/7/2021): nhận ngay Kẹo AH Kaio + Viên Trang Bị (Đơn) Té Nước + Bảo Rương Ước Nguyện*2.\n` +
        `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
    }
    if (args[0] == "ngay7") {
      return api.sendMessage("", event.threadID, () => api.sendMessage(
        'Quà Máy chủ 218: Mở vào 10 giờ ngày 20/7/2021.\n' +
        `Ngày 7: (26/7/2021): nhân kẹo AH Kaio + Kẹo AH Android 21 + Bảo Rương Ước Nguyện*2.\n` +
        `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
    }
    if (args[0] == "ngay8") {
      return api.sendMessage("", event.threadID, () => api.sendMessage(
        'Quà Máy chủ 218: Mở vào 10 giờ ngày 20/7/2021.\n' +
        `Ngày 8: (27/7/2021): nhận kẹo AH Vegeta Tà Ác + Bộ Trang Bị Broly + Bảo Rương Ước Nguyện*2.\n` +
        `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
    }
    if (args[0] == "all") {
      return api.sendMessage("", event.threadID, () => api.sendMessage(
        'Quà Máy chủ 219: Mở vào 10 giờ ngày 20/7/2021.\n' +
        `  - Mừng người chơi thứ 500: Nhận ngay Rương Vàng * 2, Thịt Nướng * 2.
        - Mừng người chơi thứ 1000: Nhận ngay Viên TB 7 sao * 10, Bảo Rương Ước Nguyện * 10.
        - Mừng người chơi thứ 2000: Nhận nhận ngay Viên TB 7 sao * 20.
        Lưu ý:
          - Quà Đặc Quyền máy chủ S219 sẽ được gửi vào thư lúc 15 h cùng ngày.
        - Quà mừng người chơi là quà chung, phát cho cả Server S219 khi đạt đủ người chơi theo yêu cầu.\n` +
        `Dữ liệu được cập nhật vào: ${hours} giờ ${minutes} phút ${seconds} giây trước.`, event.threadID, event.messageID));
    }
	}




