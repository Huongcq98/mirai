module.exports.config = {
    name: "sd",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "Huong",
    description: "Đánh bạc bằng hình thức sóc đĩa.",
    commandCategory: "game-sp",
    usages: "[chan/le] [số coin cần đặt]",
    cooldowns: 5,
};

module.exports.run = async function({ api, event, args, Currencies }) {
    const sdItems = ["⬛", "⬜"];
    const moneyUser = (await Currencies.getData(event.senderID)).money;
    var moneyBet = parseInt(args[1]);
 if (args[0] == "chan") {   
    if (isNaN(moneyBet) || moneyBet <= 0) return api.sendMessage("Số tiền đặt cược không được để trống hoặc là số âm", event.threadID, event.messageID);
	if (moneyBet > moneyUser) return api.sendMessage("Số tiền bạn đặt lớn hơn số dư của bạn!", event.threadID, event.messageID);
	if (moneyBet < 50) return api.sendMessage("Số đặt không được dưới 50!", event.threadID, event.messageID);
    var number = [], win = false;
    for (i = 0; i < 4; i++) number[i] = Math.floor(Math.random() * sdItems.length);
    if (number[0] == number[1] && number[1] == number[2] && number[2] == number[3] || number[0] == number[1] && number[2] == number[3] || number[0] == number[2] && number[1] == number[3] || number[0] == number[3] && number[1] == number[2]) {
        moneyBet *= 2;
        win = true;
    }
    switch (win) {
        case true: {
            api.sendMessage(`Kết quả chẵn lẻ: ${sdItems[number[0]]} | ${sdItems[number[1]]} | ${sdItems[number[2]]} | ${sdItems[number[3]]} \nBạn đã thắng với ${moneyBet} coin`, event.threadID, event.messageID);
            await Currencies.increaseMoney(event.senderID, moneyBet);
            break;
        }
        case false: {
            api.sendMessage(`Kết quả chẵn lẻ: ${sdItems[number[0]]} | ${sdItems[number[1]]} | ${sdItems[number[2]]} | ${sdItems[number[3]]} \nBạn đã thua và mất ${moneyBet} coin`, event.threadID, event.messageID);
            await Currencies.decreaseMoney(event.senderID, moneyBet);
            break;
        }
    }
}
else {
   if (args[0] == "le") {   
    if (isNaN(moneyBet) || moneyBet <= 0) return api.sendMessage("Số tiền đặt cược không được để trống hoặc là số âm", event.threadID, event.messageID);
	if (moneyBet > moneyUser) return api.sendMessage("Số tiền bạn đặt lớn hơn số dư của bạn!", event.threadID, event.messageID);
	if (moneyBet < 50) return api.sendMessage("Số đặt không được dưới 50!", event.threadID, event.messageID);
    var number = [], win = false;
    for (i = 0; i < 4; i++) number[i] = Math.floor(Math.random() * sdItems.length);
    if (number[0] == number[1] && number[1] == number[2] && number[2] != number[3] || number[0] != number[1] && number[1] == number[2] && number[2] == number[3] || number[0] == number[2] && number[1] != number[2] && number[2] == number[3] || number[0] == number[1] && number[1] == number[3] && number[2] != number[3]) {
        moneyBet *= 2;
        win = true;
    }
    switch (win) {
        case true: {
            api.sendMessage(`Kết quả chẵn lẻ: ${sdItems[number[0]]} | ${sdItems[number[1]]} | ${sdItems[number[2]]} | ${sdItems[number[3]]} \nBạn đã thắng với ${moneyBet} coin`, event.threadID, event.messageID);
            await Currencies.increaseMoney(event.senderID, moneyBet);
            break;
        }
        case false: {
            api.sendMessage(`Kết quả chẵn lẻ: ${sdItems[number[0]]} | ${sdItems[number[1]]} | ${sdItems[number[2]]} | ${sdItems[number[3]]} \nBạn đã thua và mất ${moneyBet} coin`, event.threadID, event.messageID);
            await Currencies.decreaseMoney(event.senderID, moneyBet);
            break;
        }
    }
}
}
}