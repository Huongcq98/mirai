module.exports.config = {
	name: "random",
	version: "0.0.1",
	hasPermssion: 0,
	credits: "Huong",
	description: "Random số từ 0 đến 99.",
	commandCategory: "Economy",
	usages: "random",
    cooldowns: 5,
    dependencies: [],
};

module.exports.run = async ({ event, api, Currencies,args }) => {
 const getRandomInt = (min, max) => {
  return Math.floor(Math.random() * (max - min)) + min;
};
  var data = await Currencies.getData(event.senderID);
  var number = getRandomInt(0, 99)
  return api.sendMessage("", event.threadID, () => api.sendMessage(number + " chính là con số may mắn.", event.threadID, event.messageID));
                };